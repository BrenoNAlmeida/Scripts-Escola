print ("=== Bem vindo a fase 2 do mundo 1 ===\n"
       "=== Os desafios dessa fase são ===\n"
       "1. Desafio 3\n"
       "2. Desafio 4\n"
       "Qual desafio você escolhe?(digite 1 ou 2)")
num = int(input())
if num == 1:
       import D3
elif num == 2:
       import D4
else:
       print("Inválido")