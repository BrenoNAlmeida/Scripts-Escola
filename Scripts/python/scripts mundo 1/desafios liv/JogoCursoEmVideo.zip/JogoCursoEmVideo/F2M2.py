print ("=== Bem vindo a Fase 2 do Mundo 2 ===\n"
       "=== Os desafios dessa fase são ===\n"
       "1. Desafio 46\n"
       "2. Desafio 47\n"
       "3. Desafio 48\n"
       "4. Desafio 49\n"
       "5. Desafio 50\n"
       "6. Desafio 51\n"
       "7. Desafio 52\n"
       "8. Desafio 53\n"
       "9. Desafio 54\n"
       "10. Desafio 55\n"
       "11. Desafio 56\n"
       "Qual desafio você escolhe?(digite um número de 1 a 11)")
num = int(input())

if num == 1:
       import D46
elif num == 2:
       import D47
elif num == 3:
       import D48
elif num == 4:
       import D49
elif num == 5:
       import D50
elif num == 6:
       import D51
elif num == 7:
       import D52
elif num == 8:
       import D53
elif num == 9:
       import D54
elif num == 10:
       import D55
elif num == 1:
       import D56
else:
       print("Inválido")