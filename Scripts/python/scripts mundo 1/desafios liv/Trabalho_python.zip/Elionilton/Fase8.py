print ("=== Bem vindo a Fase 2 do Mundo 2 ===\n"
       "=== Os desafios dessa fase são ===\n"
       "46. Desafio 46\n"
       "47. Desafio 47\n"
       "48. Desafio 48\n"
       "49. Desafio 49\n"
       "50. Desafio 50\n"
       "51. Desafio51\n"
       "52. Desafio 52\n"
       "53. Desafio 53\n"
       "54. Desafio 54\n"
       "55. Desafio 55\n"
       "56. Desafio 56\n"
       "Qual desafio você escolhe?(digite um número de 1 a 11)")
num = int(input())

if num == 46:
       import Desafio46
elif num == 47:
       import Desafio47
elif num == 48:
       import Desafio48
elif num == 49:
       import Desafio49
elif num == 50:
       import Desafio50
elif num == 51:
       import Desafio51
elif num == 52:
       import Desafio52
elif num == 53:
       import Desafio53
elif num == 54:
       import Desafio54
elif num == 55:
       import Desafio55
elif num == 56:
       import Desafio56
else:
       print("Inválido")